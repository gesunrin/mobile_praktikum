import 'package:dio/dio.dart';
import 'package:mobile_praktikum/core/network/dio_client.dart';
import 'package:mobile_praktikum/features/mahasiswa/data/models/mahasiswa_model.dart';

class MahasiswaRepository {
  final Dio _dio = DioClient.dio;

  Future<List<MahasiswaModel>> getMahasiswaList() async {
    try {
      final response = await _dio.get('/comments');

      final List<dynamic> data = response.data;

      return data
          .take(20)
          .map((e) => MahasiswaModel.fromJson(e))
          .toList();
    } catch (e) {
      throw Exception('Gagal mengambil data mahasiswa: $e');
    }
  }
}