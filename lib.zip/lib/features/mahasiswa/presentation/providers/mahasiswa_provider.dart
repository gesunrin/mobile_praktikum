import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_praktikum/features/mahasiswa/data/models/mahasiswa_model.dart';
import 'package:mobile_praktikum/features/mahasiswa/data/repositories/mahasiswa_repository.dart';

final mahasiswaRepositoryProvider = Provider<MahasiswaRepository>((ref) {
  return MahasiswaRepository();
});

final mahasiswaListProvider = FutureProvider<List<MahasiswaModel>>((ref) async {
  final repository = ref.read(mahasiswaRepositoryProvider);
  return repository.getMahasiswaList();
});