import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_praktikum/features/dosen/data/models/dosen_model.dart';
import 'package:mobile_praktikum/features/dosen/data/repositories/dosen_repository.dart';

final dosenRepositoryProvider = Provider<DosenRepository>((ref) {
  return DosenRepository();
});

final dosenListProvider = FutureProvider<List<DosenModel>>((ref) async {
  final repository = ref.read(dosenRepositoryProvider);
  return repository.getDosenList();
});