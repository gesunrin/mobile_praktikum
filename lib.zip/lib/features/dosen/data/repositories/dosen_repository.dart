import 'package:dio/dio.dart';
import 'package:mobile_praktikum/core/network/dio_client.dart';
import 'package:mobile_praktikum/features/dosen/data/models/dosen_model.dart';

class DosenRepository {
  final Dio _dio = DioClient.dio;

  Future<List<DosenModel>> getDosenList() async {
    try {
      final response = await _dio.get('/users');

      final List<dynamic> data = response.data;
      return data.map((e) => DosenModel.fromJson(e)).toList();
    } catch (e) {
      throw Exception('Gagal mengambil data dosen: $e');
    }
  }
}